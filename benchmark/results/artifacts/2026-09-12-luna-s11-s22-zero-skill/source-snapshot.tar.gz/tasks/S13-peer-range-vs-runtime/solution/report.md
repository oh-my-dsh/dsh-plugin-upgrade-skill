# S13 Peer range vs runtime reality (reference answer)

## 1. The exact runtime incompatibility

dsh **v0.1.2-alpha.4** removed `Session.events` — the eagerly materialized events array —
and replaced it with three on-demand read APIs: `seq`, `eventAt()`, and `snapshotEvents()`.
The changelog entry (in `dsh-changelog-excerpt.md`) explicitly says "developers should pay
attention to compatibility." The plugin reads `session.events` in **42 places** (per
`plugin-source-excerpt.js`), all of which now receive `undefined`. When the code tries to
iterate `undefined`, it crashes with `TypeError: events is not iterable`.

## 2. Why npm installed without warnings

The plugin's peerDependencies declare `^0.1.2-alpha.2` for every `@deepseek-ai/dsh-*`
package. The installed dsh at `0.1.2-alpha.5` satisfies this range because, in npm's
semver prerelease ordering, `0.1.2-alpha.5 > 0.1.2-alpha.2` (same base version, higher
prerelease identifier). npm's peer resolution is a **static, package-metadata-level check**:
it verifies that the installed version falls within the declared semver range.

What it does NOT do: load the plugin's code, inspect what APIs it calls, or verify that
those APIs exist in the installed version's runtime. Peer range satisfaction is a version
bounds check — full stop.

## 3. Peer range satisfaction vs runtime compatibility

| Peer range satisfaction checks | Runtime compatibility requires |
|---|---|
| Semver version bounds | API surface presence (methods, properties) |
| Package co-installability (no version conflicts) | Behavioral contracts (sync vs async, return types) |
| — | Feature flags / capability detection |

Two categories of breakage that pass peer validation but crash at runtime:

1. **API removal**: `Session.events` was removed at alpha.4. The plugin calls it; the
   property is `undefined`; iteration fails. Peer range passes because alpha.5 > alpha.2.
2. **Behavioral/contract change**: a method that used to be synchronous now returns a
   Promise, or an argument order changed. The method still exists (peer check passes),
   but calling it the old way produces wrong results or throws.

## 4. What the plugin author should have done

**Before publishing**: test against the actual target version (alpha.4+), not just the
peer floor (alpha.2). The peer range `^0.1.2-alpha.2` means "I've tested against alpha.2" —
but the plugin runs against alpha.5. The author should either:

- Tighten the peer range to `>=0.1.2-alpha.2 <0.1.2-alpha.4` (explicitly excluding the
  breaking version), OR
- Add a **runtime feature-detection guard**: `if (typeof session.snapshotEvents ===
  'function') { /* new API */ } else if (session.events !== undefined) { /* old API */ }`
  so the plugin works across both.

**To help users**: the README should state the exact dsh versions tested; the peer range
should reflect the ACTUAL compatibility boundary (where the API changed), not the earliest
version the author happened to test against.

## 5. User's pre-install check

Before installing a third-party plugin on a newer dsh than the plugin's peer floor:

1. **Read the changelog** between the peer floor (alpha.2) and your version (alpha.5):
   look for "removed", "replaced", "breaking", "developers should pay attention".
2. **Grep the plugin source** for the API surface it uses (e.g. `grep -r 'session.events'`)
   and check whether that API exists in your dsh version's type definitions.

The core principle: **peerDependencies declare the author's claimed compatibility range;
only runtime testing proves it.** A gap between the claim and reality is invisible to npm.