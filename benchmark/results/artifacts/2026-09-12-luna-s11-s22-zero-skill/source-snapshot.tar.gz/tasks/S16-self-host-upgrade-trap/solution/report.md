# S16 report — The self-host upgrade trap

## 1. Structural root cause

The agent session (and its tool worker) ARE processes of the dsh host. Running
`npm install -g @deepseek-ai/dsh@0.1.2-rc.1` from inside that session asks npm to remove and
replace the exact package tree those processes are executing from:

- npm's first phases clean/remove the installed `@deepseek-ai/dsh` package and its bins;
- the host process — whose code, native modules, and worker threads live in that tree —
  dies mid-install (the browser GUI loses its connection at that moment);
- because the host died, the tool call never completes and never returns a result to the
  agent: the session log records the call as interrupted with no durable outcome.

This is a structural failure, not a flaky one: any global host upgrade executed from a
session on that host destroys its own runtime before the install can finish.

## 2. Broken-state signature: why `dsh` vanished while the content stayed

npm installs a global CLI in two parts: the package content under
`node_modules/@deepseek-ai/dsh/` and the command shims (`dsh`, `dsh.cmd`, `dsh.ps1`) in the
global bin directory. The shim generation happens as part of the formal install flow. An
install interrupted mid-flight (or bypassed by hand-swapping the package directory) leaves:

- package CONTENT present (possibly a mix of old and new files), but
- shims missing or stale (`dsh.cmd` gone; `dsh.ps1` pointing into the removed tree),

so `dsh --version` and `dsh web` both fail with command-not-found. Package content
present ≠ a working install — the shims are the load-bearing part for the CLI. A manual
directory swap makes it strictly worse: it creates the non-standard layout seen in
`env-state.txt` that no completed install would produce.

## 3. The repair

From an EXTERNAL shell (PowerShell/terminal not spawned by dsh, with no dsh processes
running):

1. Re-run the formal, PINNED install so npm performs the complete flow and regenerates
   all three shims: `npm install -g @deepseek-ai/dsh@0.1.2-rc.1`;
2. Verify: `dsh --version` → `0.1.2-rc.1`;
3. Align any host-source checkout used for reference to the same tag (`dsh-v0.1.2-rc.1`).

Repairing by hand-copying directories or hand-writing a shim is wrong: it reproduces the
non-standard state (content without a proper install record), leaves stale shims, and the
next real npm operation may behave unpredictably. Only npm's own install flow produces a
trustworthy global install.

## 4. The protocol the agent should have followed

- RECOGNIZE: the session runs ON the host being upgraded — the agent IS the host process.
  Upgrading that host from inside is self-destruction, regardless of version.
- REFUSE & HAND OFF: the agent must not execute the global install itself. It hands the
  user the exact external procedure and waits:
  1. fully stop dsh (every window/process — the known EBUSY family: a running host holds
     native-module file locks, and a browser refresh is not a host stop);
  2. from an external terminal, run the PINNED install
     `npm install -g @deepseek-ai/dsh@<exact-version>` (never a bare package name: the
     `latest` dist-tag silently downgrades to an older line);
  3. restart `dsh web`, hard-refresh the browser, verify.

  Because the host is fully STOPPED before npm runs, there is no live process to die
  mid-install: no crash, no interrupted install, no torn shims — the failure mode of
  this incident is structurally impossible under the correct sequence. The crash is not
  a risk to mitigate but a signature of doing it wrong.
- What is old vs new: stop-host-first and pinned-version come from the established
  upgrade rules (the EBUSY/downgrade family). NEW here is the never-from-inside rule:
  even a correctly pinned install is fatal when the caller is a session on the upgraded
  host, because the failure is structural rather than a lock or versioning problem.

## 5. Prevention and the post-upgrade checklist

- Agent-side guard: detect "upgrade the host I am running on" intent (the request names
  dsh itself, and the session's host process lives under the target install) and respond
  with the hand-off procedure instead of executing. A cheap tell: the session's own
  runtime path resolving into the global @deepseek-ai/dsh tree.
- Post-upgrade checklist for this machine (the repair notes find alpha.5 → rc.1 is 252
  package.json version bumps, zero code diff):
  1. update any local brand/version marker that displays the dsh version;
  2. verify plugins load after a hard refresh (whale / progress / etc.) — no re-migration
     needed for plugins already on the 0.1.2-alpha line;
  3. optionally remove the dsh-old-* backup directories once rc.1 is confirmed stable;
     any historical version remains installable from npm for rollback.