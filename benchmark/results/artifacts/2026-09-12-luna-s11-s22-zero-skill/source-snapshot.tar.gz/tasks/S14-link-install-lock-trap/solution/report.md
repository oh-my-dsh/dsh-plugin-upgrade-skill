# S14 report — Link-install file-lock trap

## 1. What the profile entry is: a junction, so the repo IS the installed copy

profile-introspection.txt shows `LinkType: Junction` with `Target: {E:\dev\dsh-attach-input}`
and the cordis.patch.yml marker `# link:E:\dev\dsh-attach-input`. The plugin was installed
with `dsh plugin --profile web add link:<repo>`: the profile's node_modules entry is a
filesystem junction pointing at the repo working tree. Deploying repo edits therefore
requires **no copy at all** — editing `E:\dev\dsh-attach-input\lib*.js` already edited the
installed plugin. Step 4 (Copy-Item into node_modules) was never necessary for this install
mode; for a junction it is at best a no-op onto itself and at worst (as here) an accident
generator. Copying into node_modules is only meaningful for copied/registry installs.

## 2. The two locks and their owners

- **The lib files are held by the running dsh host process**, not the browser: the Node
  process that launched the web profile loaded the plugin's modules and keeps the file
  handles open (Windows). That is why closing the browser tab did not release the EBUSY —
  the lock owner is the host, so only a **full host stop** (exit every dsh window/process,
  not a page refresh, and not just closing the tab) releases it.
- **The browser refresh showed stale code because the client bundle is cached**: the host
  serves `client.js` and the browser may satisfy it from cache. After the host restarts,
  a **hard refresh (Ctrl+Shift+R / cache bypass)** is required so the new `client.js` is
  actually fetched. A plain refresh can keep running the previous bundle even though the
  host already has the new files.

## 3. Why rename-aside destroyed the source, and the recovery

Through the junction, `C:\...\node_modules\@org\dsh-attach-input` and `E:\dev\dsh-attach-input`
are **the same directory**. Renaming "the profile's" client.js to client.js.old2 renamed the
one physical file; the subsequent Copy-Item then failed ("source does not exist") because
the source path — the same file — had just been renamed. Both listings showing only .old2
files is the same directory listed twice. Recovery from the current state:

1. Rename the files back to their original names
   (`client.js.old2` → `client.js`, `index.js.old2` → `index.js`) — renaming is allowed
   even while the host holds the old handles open;
2. Verify integrity: `node --check` both files, confirm `package.json` version/exports;
3. Then follow the activation procedure below. Nothing was lost — the .old2 files ARE the
   new feature code; only the names moved.

## 4. Complete activation procedure for a link-installed lib-only Web plugin

1. Finish the repo edits (the working tree is already the installed copy — nothing to sync);
2. **Fully stop the dsh host** (quit every dsh window / process — a running host keeps old
   modules in memory even if files change on disk);
3. Restart `dsh web`;
4. **Hard-refresh the browser** (Ctrl+Shift+R) to bypass the cached client bundle;
5. Verify the new code loaded: check the plugin's version marker (version chip /
   `PLUGIN_VERSION`) or exercise the new feature; the browser console should show no
   module load errors.

## 5. The pre-flight check: determine install mode before touching files

Before any "deploy" action, inspect what the profile entry actually is:

- `Get-Item <profile>\node_modules\@org\dsh-attach-input | Select LinkType, Target` —
  `LinkType: Junction` (with the repo Target) means a link install: repo edits ARE live,
  never copy into node_modules;
- or read `cordis.patch.yml` for the `link:<path>` install marker;
- an empty LinkType means a copied/registry install, where replacing files (after a full
  host stop) is the mechanism — but even then the EBUSY rule applies: the host process
  must be stopped first.

Generic "copy your build into node_modules" advice is actively harmful for link installs:
it masks the fact that the repo is the source of truth, invites exactly this EBUSY/rename
accident, and can leave the plugin with no entry files.

## 6. Regression / prevention notes

- Document the install mode in the plugin README's verification section ("link install:
  restart host + hard refresh; never copy files");
- Treat "Copy-Item EBUSY under .dsh\profiles" as a smell: identify the lock owner
  (running host) and the install mode (junction) before retrying anything;
- Never rename-aside files under a path you have not resolved (junction traversal makes
  "two" directories one).
