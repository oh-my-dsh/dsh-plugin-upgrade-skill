# S11 Lazy-chunk rollout diagnosis (reference answer)

## 1. Why the split-chunk attempt failed

A browser resolves a dynamically imported module's OWN relative imports as URLs **relative to
that module's URL**. With the bundler's default code-splitting, `mermaid-chunk.js` is a thin
entry whose body is a web of `import("./src-BfvxrPJe.js")`, `import("./pie-WAS4IAKB-….js")`
and ~95 more content-hashed siblings. Each of those URLs must be served under the exact same
prefix with the exact hashed name and a JavaScript MIME. My route shipped/served only the
entry file, so the first sibling import 404'd, and because the failing import chain roots at
the entry, the browser reports the whole `mermaid-chunk.js` import as
"Failed to fetch dynamically imported module" — even though the entry itself returned 200.

**Build-side fix**: disable code splitting for the chunk — bundle the dependency into ONE
self-contained ESM file (the library's internal dynamic imports get inlined). One file, one
request, and the entire class of sibling-name/MIME/relative-resolution failures disappears.

## 2. The Windows-only 403 — the precise mechanism

The route's containment guard compares strings:

`normalize(realpathSync(abs)).startsWith(LIB_DIR + sep)`

On the production host (evidence `ci-note.md`):

- `LIB_DIR` keeps the **installed** casing: `E:\dsh\…\lib`;
- `realpathSync` on Windows **normalizes the drive letter to lowercase**: it returned
  `e:\dsh\…\lib\mermaid-chunk.js`.

A JavaScript `startsWith` is byte-wise case-sensitive, so `e:\…` does not start with
`E:\…` — a path that is plainly **inside** the lib directory is misjudged as escaping, and
the guard answers **403**. On Linux CI nothing changes case (the filesystem is case-sensitive
and consistent), so the same compare passes there; the maintainer's laptop likely mounted the
profile on a drive whose installed casing happened to match (or tooling lower-cased both).
The bug is in the **comparison**, not "Windows being unreliable": the platform difference is
only what makes the latent flaw observable.

## 3. Fix direction for the guard (+ one serving requirement)

Use `path.relative(LIB_DIR, candidate)` and accept only a result that is non-empty, does not
start with `..`, and is not absolute:

- `path.relative` computes containment semantically, so case and separator differences in the
  drive prefix do not matter; a genuine escape (or a cross-drive path, where relative returns
  an absolute path) is still rejected by the `isAbsolute`/`..` checks.
- Keep the realpath pass as defense-in-depth, judged by the same relative-based rule.

Serving requirement besides correctness: the route must answer with a **JavaScript MIME type**
(`application/javascript`); browsers refuse `import()` of a module served as, say,
`text/plain` or `application/octet-stream` even when the bytes are fine.

## 4. The Ctrl+scroll double-fire under the zoom modal

Two listeners see one gesture: the pane registers a **document-level capture** wheel listener
for Ctrl+wheel font sizing (capture runs before target handlers), and the fullscreen modal has
its own wheel handler for zoom. Both are alive while the modal is open, so one Ctrl+scroll
zooms the diagram AND resizes the pane font.

**Ownership rule**: while the modal is open it owns ALL wheel events — the modal handler must
`preventDefault()` + `stopPropagation()` on every wheel it handles, AND the pane's
document-capture handler must explicitly stand down while the modal is present (e.g. check for
the modal element before acting; stopPropagation alone cannot disarm an earlier capture-phase
listener on an ancestor).

## 5. Regression tests that would have caught all three

1. **Chunk import failure → fallback**: with the chunk URL stubbed unreachable, a mermaid fence
   must render the original code block (not an error, not a blank).
2. **Containment, case variant**: request a path whose drive-letter casing differs from the
   configured base but is inside the directory → must be **served** (200), not 403; and a real
   escape (`../` traversal, absolute foreign path) → 403. This test fails on the buggy
   `startsWith` guard on any case-mismatching fixture and passes with `path.relative`.
3. **Single-file chunk**: build assertion that the chunk artifact set for the feature is
   exactly one file (no content-hashed siblings emitted) — catches a bundler-config regression
   before shipping.
4. **Modal ownership**: with the zoom modal open, a Ctrl+wheel event inside it must change the
   diagram scale and leave the pane font variable untouched.
