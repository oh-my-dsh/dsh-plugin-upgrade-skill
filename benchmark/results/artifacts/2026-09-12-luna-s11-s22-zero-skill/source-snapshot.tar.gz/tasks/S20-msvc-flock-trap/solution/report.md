# S20 Reference Report

1. **What fails and why**: `pnpm install` fails at the install script of
   `fs-ext@2.1.1` — a pinned dependency of
   `@deepseek-ai/dsh-session-persistence-jsonl` (see `manifest-excerpt.json`).
   Its install step runs `node-gyp configure build`, and this machine has no
   Visual Studio / MSVC toolchain, so gyp aborts with `find VS` errors
   (`install-error.log`).

2. **Why `--ignore-scripts` cannot fix it**: `src/lease.ts` imports `flock`
   from `fs-ext` statically at module top (`lease-excerpt.md`). The module must
   exist and load regardless of how it was built; skipping the build leaves no
   binary and the import throws at boot.

3. **Which lock path Windows takes**: `lease-excerpt.md` states Windows "holds
   a named kernel semaphore derived from that path — never a file lock or
   handle" and "Windows has no lock file at all"; `win32-excerpt.ts` shows the
   `CreateSemaphoreW` / `WaitForSingleObject` / `ReleaseSemaphore` bindings.
   `flock` is the POSIX-only branch, so the native module is dead code on
   Windows.

4. **Fix plan (no Visual Studio, no upstream changes)**: add a pnpm patch
   following the repository's existing `patches/node-pty@*.patch` precedent:
   - rewrite the install script to run `node-gyp configure build` only on
     non-Windows platforms (no-op on win32);
   - give the entry a pure-JS `flock` fallback (warn once, no-op) on Windows;
     Linux/macOS keep the native build;
   - register the patch in `pnpm-workspace.yaml` (`patchedDependencies` and
     `allowBuilds`) and re-run `pnpm install`.

5. **Card**: DSH-0.1.3-A1-03 covers this finding (install channel, Windows
   fs-ext native build; pnpm-patch recipe).
